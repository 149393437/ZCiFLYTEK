
//
//  MainViewController.m
//  Xunfei_demo_1401
//
//  Created by ZhangCheng on 14-4-4.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "MainViewController.h"
#import "ZCiFLYTEK.h"
@interface MainViewController ()

@end

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //读  识别
    UIButton*button=[UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor=[UIColor redColor];
    [button setTitle:@"读取" forState:UIControlStateNormal];
    button.frame=CGRectMake(0, 100, 100, 100);
    [self.view addSubview:button];
    
    
    UIButton*button1=[UIButton buttonWithType:UIButtonTypeCustom];
    button1.backgroundColor=[UIColor greenColor];
    [button1 setTitle:@"识别" forState:UIControlStateNormal];
    button1.frame=CGRectMake(200, 100, 100, 100);
    [self.view addSubview:button1];
    
    [button addTarget:self action:@selector(read) forControlEvents:UIControlEventTouchUpInside];
    [button1 addTarget:self action:@selector(recognition) forControlEvents:UIControlEventTouchUpInside];
    
}
-(void)read{
//读取
    ZCiFLYTEK*xunfei=[ZCiFLYTEK shareManager];
    [xunfei playStart:@"讯飞是最好的"];
}
-(void)recognition{
//识别
    ZCiFLYTEK*xunfei=[ZCiFLYTEK shareManager];
    [xunfei discernBlock:^(NSString *a) {
        NSLog(@"识别出来的结果~%@",a);
    }];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
